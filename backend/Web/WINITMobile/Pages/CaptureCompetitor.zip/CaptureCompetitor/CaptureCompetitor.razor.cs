﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Winit.Modules.CaptureCompetitor.Model.Interfaces;
using Winit.Modules.FileSys.Model.Interfaces;
using Winit.Modules.Scheme.BL.Classes;
using Winit.Shared.CommonUtilities.Common;
using Winit.Shared.Models.Common;
using Winit.Shared.Models.Events;
using Winit.UIComponents.Common.CustomControls;
using WINITMobile.Data;
namespace WINITMobile.Pages.CaptureCompetitor;

public partial class CaptureCompetitor
{
    private bool showCaptureForm = false;
    private bool showDetailsModal = false;
    private WinitTextBox wtbSearch;
    private List<ICaptureCompetitor> items = new();
    private List<ISelectionItem> brands = new();
    private ICaptureCompetitor selectedItem;
    //public string ImgFolderPath { get; set; }
    private string ImgFolderPath = Path.Combine(FileSystem.AppDataDirectory, "Images");
    public bool IsCaputureImage { get; set; }
    private FileCaptureData fileCaptureData = new FileCaptureData
    {
        AllowedExtensions = new List<string> { ".jpg", ".png" },
        IsCameraAllowed = true,
        IsGalleryAllowed = true,
        MaxNumberOfItems = 1,
        MaxFileSize = 10 * 1024 * 1024,
        EmbedLatLong = true,
        EmbedDateTime = true,
        LinkedItemType = "ItemType",
        LinkedItemUID = "ItemUID",
        EmpUID = "EmployeeUID",
        JobPositionUID = "JobPositionUID",
        IsEditable = true,
        Files = new List<FileSys>()
    };

    protected override async Task OnInitializedAsync()
    {
        // Load items and brands from the view model
        // items = await _viewmodel.GetItemsAsync();
        // brands = await _viewmodel.GetBrandsAsync();
        await _viewmodel.PopulateViewModel();
        if(_appUser?.SelectedCustomer?.Code != null)
        {
            _dataManager.SetData("CaptureCompetitor", _appUser.SelectedCustomer.Code + "_" + sixGuidstring());
        }
           
        //ImgFolderPath = Path.Combine(_appConfigs.BaseFolderPath,
        //FileSysTemplateControles.GetCaptureCapitatorImageFolderPath(_dataManager.GetData("CaptureCompetitor").ToString()));
    }

    public string sixGuidstring()
    {
        Guid newGuid = Guid.NewGuid();
        // Convert the GUID to a string and take the first 8 characters without hyphens
        string eightDigitGuid = newGuid.ToString("N").Substring(0, 8);
        return eightDigitGuid;
    }
    private async Task WinitTextBox_OnSearch(string searchString)
    {
        // Filter items based on search
        // items = await _viewmodel.SearchItemsAsync(searchString);
        StateHasChanged();
    }

    private async Task HandleChannelSelection(DropDownEvent dropDownEvent)
    {
        if (dropDownEvent != null)
        {
            // await _viewModel.OnChannelpartnerSelected(dropDownEvent);
            if (dropDownEvent.SelectionItems != null && dropDownEvent.SelectionItems.Count > 0)
            {
                _viewmodel.CreateCaptureCompetitor.OurBrand = dropDownEvent.SelectionItems.FirstOrDefault().Label;
            }
            else
            {
                //_viewModel.PreviousOrdersList.Clear();
            }
        }
        //_viewModel.SellOutMaster.SellOutSchemeLines!.Clear();
        StateHasChanged();
    }

    //image
    private void OnImageDeleteClick(string fileName)
    {
        IFileSys fileSys = _viewmodel.ImageFileSysList.Find
            (e => e.FileName == fileName);
        if (fileSys is not null) _viewmodel.ImageFileSysList.Remove(fileSys);
    }
    
    private async Task OnImageCapture((string fileName, string folderPath) data)
    {
        string relativePath = "";

        // Ensure UID is available and not empty
        string selectedCustomerCode = _appUser?.SelectedJobPosition?.UID;

        if (!string.IsNullOrWhiteSpace(selectedCustomerCode))
        {
            relativePath = FileSysTemplateControles.GetCaptureCapitatorImageFolderPath(selectedCustomerCode) ?? "";
        }

        IFileSys fileSys = ConvertFileSys("CaptureCompetitor", "12", "CaptureCompetitor", "Image",
            data.fileName, _appUser.Emp?.Name, data.folderPath);
        fileSys.SS = -1;
        fileSys.RelativePath = relativePath;
        _viewmodel.ImageFileSysList.Add(fileSys);
        _viewmodel.FolderPathImages = data.folderPath;
        await Task.CompletedTask;
    }
    private void ShowCaptureForm()
    {
        showCaptureForm = true;
    }

    private void CancelCaptureForm()
    {
        showCaptureForm = false;
    }

    private void ShowItemDetails(ICaptureCompetitor item)
    {
        selectedItem = item;
        showDetailsModal = true;
    }

    private void CloseModal()
    {
        showDetailsModal = false;
    }

    private async Task SaveData()
    {
        // Save capture data logic
        if (await _viewmodel.SaveCompitator() >= 1)
        {
            await _alertService.ShowConfirmationAlert("Success", "Succesfully Captured", null, null,null);
            await _viewmodel.GetAllCapatureCampitators();
            _viewmodel.CreateCaptureCompetitor = new Winit.Modules.CaptureCompetitor.Model.Classes.CaptureCompetitor();
            _viewmodel.ImageFileSysList = new();
            showCaptureForm = false;
            StateHasChanged();
        }
        else
        {
            await _alertService.ShowErrorAlert("Failed", "Failed to Captured");
        }

    }


}
